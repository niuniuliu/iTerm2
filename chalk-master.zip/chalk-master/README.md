chalk
=====

A theme I made for iTerm. zsh and vim and Sublime Text themes coming soon!

![Chalk in action](http://i.imgur.com/FHm1EpQ.png "Chalk")

Numbers 000-007 are the ones that comprise the dark color palette, and 008-014 comprise the light color palette.

Pull requests with chalk ported for other programs would be awesome.
