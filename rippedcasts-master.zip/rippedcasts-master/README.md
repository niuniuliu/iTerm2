#rippedcasts

Contains similar-to-railscasts themes for:
- Xcode 
- Emacs
- iTerm2
- OSX terminal
