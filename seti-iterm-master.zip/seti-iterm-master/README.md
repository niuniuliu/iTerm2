Seti for iTerm
==========

A subtle dark colored syntax theme for iTerm.

![Screenshot](http://cl.ly/image/3V1o343k3F3b/Screen%20Shot%202014-09-16%20at%201.21.25%20PM.png)

Based off of https://github.com/jesseweed/seti-syntax. All credit goes to Jesse Weed.
