This is a dark iTerm theme with glowing colors.

[baskerville](https://github.com/baskerville/iTerm-2-Color-Themes) made a nice .Xdefaults-to-iTerm2 script. More themes on his github.

![Screenshot](http://ompldr.org/vOHB5OQ) 
![Screenshot VIM](http://ompldr.org/vZmN0dg)


To install:<br>
- Download or clone git, double click on 'hardcore.itermcolors'<br>
- Press CMD+i or CMD+, in iTerm2.app<br>
- Go to "Profiles" -> Tab "Colors"<br>
- Click on "Load Presets..." switch to "hardcore"<br>

FAQ:<br>

Q: How can I talk to you?<br>
A:<br>
- Jabber: hard@core.im<br>
- IRC: irc.freenode.net #macosx (for german users ##macintosh.de (yes two ##)<br>

Greetz & Beats<br>
Hardcore