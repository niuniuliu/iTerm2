iterm-clrs
==========

An iTerm theme based on [@mrmrs](https://github.com/mrmrs) nicer color palette for the web. http://clrs.cc/

![](http://cl.ly/image/3A08113n072W/content)
