#SpaceGray-iTerm

The slick [https://github.com/kkga/spacegray](SpaceGray) theme for iTerm.
