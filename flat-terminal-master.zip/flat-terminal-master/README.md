flat-terminal
=============

Flat design colours applied to terminal. Terminal is now sweeter than ever!

Available for Terminal and iTerm.

Dribbble link: http://dribbble.com/shots/1021755-Flat-Terminal-Theme

![flat-terminal preview](https://raw.github.com/hamstu/flat-terminal/master/screenshot.png)
