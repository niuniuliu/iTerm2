# Argonaut Theme for iTerm

I really love the Argonaut Textmate Theme by David Lee (unfortunately, no "official" link seems to be working at this time), and after porting it to vim I also felt like having it in iTerm, so here it is. Import it into iTerm by going to: Preferences -> Profiles -> Colors -> Load Presets -> Import.

![Screen Shot](https://github.com/effkay/iTerm-argonaut/raw/master/screenshot.png)
