iTerm2 thayer bright color scheme
========
A color scheme inspired by [thayer](https://github.com/baskerville/iTerm-2-Color-Themes/blob/master/thayer.itermcolors)

Screenshots
========
![image](http://i.imgur.com/Pu3sdck.png)

![image](http://i.imgur.com/3lfxp5I.png)

![image](http://i.imgur.com/7tjTXEf.png)



Scripts used in demonstration
========
[Color tests](https://github.com/t3chnoboy/colorscripts)