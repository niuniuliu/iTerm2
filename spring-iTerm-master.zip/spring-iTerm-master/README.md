iTerm2 Spring color scheme
========


Screenshots
========
![image](http://i.imgur.com/wwxmYzL.png)

![image](http://i.imgur.com/FJPq6RK.png)

![image](http://i.imgur.com/1InShq3.png)

![image](http://i.imgur.com/dH7S4pl.png)