# Cobalt2 for iTerm2 and ZSH

Two things for lovers of the [Sublime Text Theme](https://github.com/wesbos/cobalt2). Cobalt2 in your terminal!

![](http://wes.io/Ub3k/content)

`cobalt2.itermcolors` is for anyone who uses iTerm2 and wants the colours. The `cobalt1.zsh-theme` is the prompt layout for zsh users. 

They work well together! You will need to install the patched powerline font as well: <https://github.com/Lokaltog/powerline-fonts>
