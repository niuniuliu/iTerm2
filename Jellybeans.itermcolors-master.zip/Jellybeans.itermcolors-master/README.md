# Jellybeans.itermcolors

![screen shot of jellybeans.itermcolors](http://i.imgur.com/OnZfIeP.png)
